# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build & Run

```bash
# 打包
mvn clean package -DskipTests

# 运行（Spring Boot，端口 8081）
mvn spring-boot:run

# 访问地址
http://localhost:8081
```

## 依赖注意事项

- Spring Boot 版本：**3.2.3**
- MyBatis-Plus 必须使用 **`mybatis-plus-spring-boot3-starter`**（非 `mybatis-plus-boot-starter`），否则启动报 `Invalid value type for attribute 'factoryBeanObjectType'`
- 当前版本：`mybatis-plus-spring-boot3-starter 3.5.7`

## 架构概览

本项目是一个**工单管理系统**，由两部分组成：

1. **管理后台（Thymeleaf MVC）** —— 供技术人员登录操作，路由由 `WebController` 处理
2. **对外 REST API** —— 供外部 AgentDemo（AI对话系统）调用，路由前缀 `/api/ticket/**`，由 `TicketApiController` 处理

### 请求认证

API 接口通过 HTTP Header `X-Api-Key` 鉴权，密钥配置在 `application.yml` 的 `ticket.api-key`，当前值为 `agent-demo-secret-key`。

管理后台通过 Session 鉴权（`HttpSession` 存储 `SysUser`），无 Spring Security，登录逻辑在 `WebController.doLogin`。

### 工单状态流转

```
PENDING → HANDLING（接受工单）→ RESOLVED（填写处理结果）
任意状态 → CLOSED（强制关闭）
```

### 数据层

- MyBatis-Plus 全自动 CRUD，Mapper 均继承 `BaseMapper<T>`，无自定义 XML
- 逻辑删除字段：`deleted`（0=正常，1=已删除），由 MyBatis-Plus 全局配置自动处理
- `createTime` / `updateTime` 由 `MyMetaObjectHandler` 自动填充
- 工单编号生成：`TK-yyyyMMdd-seq`，序号用内存 `AtomicInteger`（重启归零，生产环境需改为 DB 序列或 Redis）

### 数据库

- MySQL，数据库名：`ticket_system`
- 建表语句：`src/main/resources/schema.sql`
- 初始账号：`admin/admin123`（管理员）、`tech/tech123`（技术人员）
- 密码明文存储（学习项目）

### API 接口

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/ticket/create` | 创建工单（AgentDemo调用） |
| GET  | `/api/ticket/status/{ticketNo}` | 查询工单状态 |

### 管理后台路由

| 路径 | 说明 |
|------|------|
| `/` 或 `/login` | 登录页 |
| `/dashboard` | 统计首页 |
| `/tickets` | 工单列表（支持状态筛选、关键词搜索、分页） |
| `/tickets/{id}` | 工单详情 |
| `/tickets/{id}/accept` | 接受工单 |
| `/tickets/{id}/resolve` | 解决工单 |
| `/tickets/{id}/close` | 关闭工单 |
