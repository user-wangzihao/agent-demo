package com.ticket.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ticket.entity.SysUser;
import com.ticket.entity.Ticket;
import com.ticket.service.TicketService;
import com.ticket.service.UserService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * 管理后台页面控制器（Thymeleaf）
 */
@Controller
@RequiredArgsConstructor
public class WebController {

    private final TicketService ticketService;
    private final UserService userService;

    // ==================== 登录 ====================

    @GetMapping({"/", "/login"})
    public String loginPage(HttpSession session) {
        if (session.getAttribute("user") != null) {
            return "redirect:/dashboard";
        }
        return "login";
    }

    @PostMapping("/login")
    public String doLogin(@RequestParam String username,
                          @RequestParam String password,
                          HttpSession session,
                          RedirectAttributes ra) {
        SysUser user = userService.login(username, password);
        if (user == null) {
            ra.addFlashAttribute("error", "用户名或密码错误");
            return "redirect:/login";
        }
        session.setAttribute("user", user);
        return "redirect:/dashboard";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    // ==================== 首页/统计 ====================

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        if (session.getAttribute("user") == null) return "redirect:/login";

        model.addAttribute("pendingCount", ticketService.countByStatus("PENDING"));
        model.addAttribute("handlingCount", ticketService.countByStatus("HANDLING"));
        model.addAttribute("resolvedCount", ticketService.countByStatus("RESOLVED"));
        model.addAttribute("closedCount", ticketService.countByStatus("CLOSED"));

        // 最近5条待处理工单
        Page<Ticket> recentPage = ticketService.pageList(1, 5, "PENDING", null);
        model.addAttribute("recentTickets", recentPage.getRecords());

        return "dashboard";
    }

    // ==================== 工单列表 ====================

    @GetMapping("/tickets")
    public String ticketList(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String keyword,
            HttpSession session, Model model) {

        if (session.getAttribute("user") == null) return "redirect:/login";

        Page<Ticket> pageResult = ticketService.pageList(page, size, status, keyword);
        model.addAttribute("page", pageResult);
        model.addAttribute("currentStatus", status);
        model.addAttribute("keyword", keyword);
        return "ticket/list";
    }

    // ==================== 工单详情 ====================

    @GetMapping("/tickets/{id}")
    public String ticketDetail(@PathVariable Long id, HttpSession session, Model model) {
        if (session.getAttribute("user") == null) return "redirect:/login";

        Ticket ticket = ticketService.getById(id);
        if (ticket == null) return "redirect:/tickets";

        model.addAttribute("ticket", ticket);
        return "ticket/detail";
    }

    // ==================== 接受工单 ====================

    @PostMapping("/tickets/{id}/accept")
    public String acceptTicket(@PathVariable Long id, HttpSession session, RedirectAttributes ra) {
        if (session.getAttribute("user") == null) return "redirect:/login";

        SysUser user = (SysUser) session.getAttribute("user");
        try {
            ticketService.acceptTicket(id, user.getId(), user.getNickname());
            ra.addFlashAttribute("success", "已接受工单，请及时处理");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/tickets/" + id;
    }

    // ==================== 解决工单 ====================

    @PostMapping("/tickets/{id}/resolve")
    public String resolveTicket(@PathVariable Long id,
                                @RequestParam String resolution,
                                @RequestParam(required = false) String remark,
                                @RequestParam(value = "addToFaqCandidate", defaultValue = "false")
                                boolean addToFaqCandidate,
                                HttpSession session, RedirectAttributes ra) {
        SysUser user = (SysUser) session.getAttribute("user");
        if (user == null) return "redirect:/login";

        try {
            ticketService.resolveTicket(id, resolution, remark,
                    addToFaqCandidate, user.getId(), user.getNickname());
            if (addToFaqCandidate) {
                ra.addFlashAttribute("success", "工单已标记为已解决,并加入 FAQ 候选池");
            } else {
                ra.addFlashAttribute("success", "工单已标记为已解决");
            }
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/tickets/" + id;
    }

    // ==================== 关闭工单 ====================

    @PostMapping("/tickets/{id}/close")
    public String closeTicket(@PathVariable Long id, HttpSession session, RedirectAttributes ra) {
        if (session.getAttribute("user") == null) return "redirect:/login";

        try {
            ticketService.closeTicket(id);
            ra.addFlashAttribute("success", "工单已关闭");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/tickets/" + id;
    }


}
