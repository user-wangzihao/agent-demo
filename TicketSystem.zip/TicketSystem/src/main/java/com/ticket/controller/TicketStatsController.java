package com.ticket.controller;

import com.ticket.dto.Result;
import com.ticket.mapper.TicketMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;

/**
 * 工单统计 API —— 供 AgentDemo 大屏拉取今日工单数.
 *
 * <p>鉴权方式与 {@link TicketApiController} 完全一致：Header X-Api-Key = ticket.api-key.
 * 绕开 MCP 通道（MCP 给 LLM Agent 用），REST 给数据集成用，职责分离.</p>
 *
 * <p>端点：{@code GET /api/stats/today-count}</p>
 */
@Slf4j
@RestController
@RequestMapping("/api/stats")
@RequiredArgsConstructor
public class TicketStatsController {

    private final TicketMapper ticketMapper;

    @Value("${ticket.api-key}")
    private String apiKey;

    private boolean validateApiKey(String key) {
        return apiKey.equals(key);
    }

    /**
     * 返回今日（服务端当地时间 00:00 ~ 次日 00:00）创建的工单数.
     *
     * <p>响应体 data 字段直接是 Long，前端/AgentDemo 取 {@code data} 字段即可.</p>
     *
     * <pre>
     * curl -H "X-Api-Key: capybara" http://localhost:8081/api/stats/today-count
     * {"code":200,"message":"success","data":3}
     * </pre>
     */
    @GetMapping("/today-count")
    public Result<Long> getTodayCount(
            @RequestHeader(value = "X-Api-Key", required = false) String key) {

        if (!validateApiKey(key)) {
            return Result.unauthorized();
        }

        try {
            LocalDate today = LocalDate.now();
            LocalDate tomorrow = today.plusDays(1);
            long count = ticketMapper.countCreatedInRange(today, tomorrow);
            log.info("[TICKET-STATS] today-count={} date={}", count, today);
            return Result.success(count);
        } catch (Exception e) {
            log.error("[TICKET-STATS] today-count query failed", e);
            return Result.fail("查询今日工单数失败: " + e.getMessage());
        }
    }
}