package com.ticket.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ticket.entity.SysUser;
import com.ticket.entity.TicketFaqCandidate;
import com.ticket.service.FaqCandidateService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.HashMap;
import java.util.Map;

/**
 * FAQ 候选 REST API(第五刀 Batch 2)。
 *
 * <p>路径前缀 /api/faq-candidate;Web 路由 /faq-candidate/** 在 Batch 3 的
 * FaqCandidateWebController 中实现。</p>
 *
 * <p><b>鉴权</b>:基于 HttpSession 中的"user"属性(同 WebController 风格)。
 * 未登录则返回 401。</p>
 */
@Slf4j
@RestController
@RequestMapping("/api/faq-candidate")
@RequiredArgsConstructor
public class FaqCandidateApiController {

    private final FaqCandidateService candidateService;
    private final RestTemplate restTemplate;

    @Value("${agent-demo.base-url}")
    private String agentDemoBaseUrl;

    @Value("${agent-demo.internal-api-key}")
    private String agentDemoInternalApiKey;

    // ==================== 候选 CRUD ====================

    /**
     * 当前技术员的候选列表(分页, 可按 submitStatus 筛选)。
     */
    @GetMapping("/page")
    public ResponseEntity<?> pageMyCandidates(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) String submitStatus,
            HttpSession session) {
        SysUser user = currentUser(session);
        if (user == null) return unauthorized();

        Page<TicketFaqCandidate> page = candidateService.pageMyCandidates(
                user.getId(), submitStatus, pageNum, pageSize);
        return ResponseEntity.ok(Map.of(
                "code", 200,
                "data", Map.of(
                        "records", page.getRecords(),
                        "total", page.getTotal(),
                        "pageNum", pageNum,
                        "pageSize", pageSize
                )
        ));
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id, HttpSession session) {
        SysUser user = currentUser(session);
        if (user == null) return unauthorized();

        TicketFaqCandidate c = candidateService.getById(id);
        if (c == null) return ResponseEntity.status(404)
                .body(Map.of("code", 404, "message", "候选不存在"));

        // 权限:只能看自己的
        if (!user.getId().equals(c.getMarkedById())) {
            return ResponseEntity.status(403)
                    .body(Map.of("code", 403, "message", "无权访问该候选"));
        }
        return ResponseEntity.ok(Map.of("code", 200, "data", c));
    }

    @PutMapping
    public ResponseEntity<?> update(@RequestBody TicketFaqCandidate update, HttpSession session) {
        SysUser user = currentUser(session);
        if (user == null) return unauthorized();

        TicketFaqCandidate existing = candidateService.getById(update.getId());
        if (existing == null) return ResponseEntity.status(404)
                .body(Map.of("code", 404, "message", "候选不存在"));
        if (!user.getId().equals(existing.getMarkedById())) {
            return ResponseEntity.status(403)
                    .body(Map.of("code", 403, "message", "无权修改该候选"));
        }

        try {
            candidateService.updateCandidate(update);
            return ResponseEntity.ok(Map.of("code", 200, "message", "更新成功"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("code", 400, "message", e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id, HttpSession session) {
        SysUser user = currentUser(session);
        if (user == null) return unauthorized();

        TicketFaqCandidate existing = candidateService.getById(id);
        if (existing == null) return ResponseEntity.status(404)
                .body(Map.of("code", 404, "message", "候选不存在"));
        if (!user.getId().equals(existing.getMarkedById())) {
            return ResponseEntity.status(403)
                    .body(Map.of("code", 403, "message", "无权删除该候选"));
        }

        candidateService.deleteCandidate(id);
        return ResponseEntity.ok(Map.of("code", 200, "message", "删除成功"));
    }

    // ==================== 图片上传代理 ====================

    /**
     * 图片上传代理:技术员浏览器 → TicketSystem → AgentDemo /internal/file/upload → MinIO。
     * <p>返回 AgentDemo MinIO 的图片 URL,技术员可直接把 URL 拼到 question_images / answer_images。</p>
     */
    @PostMapping("/upload-image")
    public ResponseEntity<?> uploadImage(@RequestParam("file") MultipartFile file,
                                         HttpSession session) {
        SysUser user = currentUser(session);
        if (user == null) return unauthorized();

        if (file == null || file.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("code", 400, "message", "文件不能为空"));
        }

        try {
            // 构造 multipart 转发请求
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);
            headers.set("X-Internal-Api-Key", agentDemoInternalApiKey);

            MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
            ByteArrayResource fileAsResource = new ByteArrayResource(file.getBytes()) {
                @Override
                public String getFilename() {
                    return file.getOriginalFilename();
                }
            };
            body.add("file", fileAsResource);

            org.springframework.http.HttpEntity<MultiValueMap<String, Object>> requestEntity =
                    new org.springframework.http.HttpEntity<>(body, headers);

            String url = agentDemoBaseUrl + "/internal/file/upload";
            @SuppressWarnings("unchecked")
            ResponseEntity<Map> response = restTemplate.postForEntity(url, requestEntity, Map.class);

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                Object data = response.getBody().get("data");
                log.info("[upload-image] 上传成功 fileName={} url={}",
                        file.getOriginalFilename(), data);
                return ResponseEntity.ok(Map.of(
                        "code", 200,
                        "data", data == null ? "" : data.toString()
                ));
            }
            log.warn("[upload-image] AgentDemo 返回非 2xx response={}", response);
            return ResponseEntity.status(502)
                    .body(Map.of("code", 502, "message", "AgentDemo 上传失败"));
        } catch (Exception e) {
            log.error("[upload-image] 上传失败", e);
            return ResponseEntity.status(500)
                    .body(Map.of("code", 500, "message", "上传失败:" + e.getMessage()));
        }
    }

    /**
     * 提交候选到 AgentDemo(走 webhook)。
     */
    @PostMapping("/{id}/submit")
    public ResponseEntity<?> submit(@PathVariable Long id, HttpSession session) {
        SysUser user = currentUser(session);
        if (user == null) return unauthorized();

        try {
            candidateService.submitToAgent(id, user.getId());
            return ResponseEntity.ok(Map.of("code", 200, "message", "提交成功"));
        } catch (Exception e) {
            log.error("[submit] 提交候选失败 candidateId={}", id, e);
            return ResponseEntity.badRequest()
                    .body(Map.of("code", 400, "message", e.getMessage()));
        }
    }

    // ==================== 辅助 ====================

    private SysUser currentUser(HttpSession session) {
        Object o = session.getAttribute("user");
        return o instanceof SysUser u ? u : null;
    }

    private ResponseEntity<Map<String, Object>> unauthorized() {
        Map<String, Object> map = new HashMap<>();
        map.put("code", 401);
        map.put("message", "未登录");
        return ResponseEntity.status(401).body(map);
    }
}