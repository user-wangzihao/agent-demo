package com.ticket.controller;

import com.ticket.dto.CreateTicketRequest;
import com.ticket.dto.Result;
import com.ticket.entity.Ticket;
import com.ticket.service.TicketService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 对外API接口 —— 供 AgentDemo 调用
 * 所有接口需要在 Header 中携带 X-Api-Key
 */
@Slf4j
@RestController
@RequestMapping("/api/ticket")
@RequiredArgsConstructor
public class TicketApiController {

    private final TicketService ticketService;

    @Value("${ticket.api-key}")
    private String apiKey;

    /**
     * 验证API Key
     */
    private boolean validateApiKey(String key) {
        return apiKey.equals(key);
    }

    /**
     * 创建工单
     * POST /api/ticket/create
     * Header: X-Api-Key: agent-demo-secret-key
     */
    @PostMapping("/create")
    public Result<Map<String, Object>> create(
            @RequestHeader(value = "X-Api-Key", required = false) String key,
            @RequestBody CreateTicketRequest req) {

        if (!validateApiKey(key)) return Result.unauthorized();

        try {
            Ticket ticket = ticketService.createTicket(req);
            Map<String, Object> data = new HashMap<>();
            data.put("ticketNo", ticket.getTicketNo());
            data.put("ticketId", ticket.getId());
            data.put("status", ticket.getStatus());
            data.put("message", "工单已提交，技术人员将尽快处理，您可以通过工单编号查询处理进度");
            return Result.success(data);
        } catch (Exception e) {
            log.error("创建工单失败", e);
            return Result.fail("创建工单失败：" + e.getMessage());
        }
    }

    /**
     * 查询工单状态
     * GET /api/ticket/status/{ticketNo}
     * Header: X-Api-Key: agent-demo-secret-key
     */
    @GetMapping("/status/{ticketNo}")
    public Result<Map<String, Object>> queryStatus(
            @RequestHeader(value = "X-Api-Key", required = false) String key,
            @PathVariable String ticketNo) {

        if (!validateApiKey(key)) return Result.unauthorized();

        Ticket ticket = ticketService.getByTicketNo(ticketNo);
        if (ticket == null) return Result.fail("工单不存在: " + ticketNo);

        Map<String, Object> data = new HashMap<>();
        data.put("ticketNo", ticket.getTicketNo());
        data.put("title", ticket.getTitle());
        data.put("status", ticket.getStatus());
        data.put("statusLabel", getStatusLabel(ticket.getStatus()));
        data.put("priority", ticket.getPriority());
        data.put("handlerName", ticket.getHandlerName());
        data.put("resolution", ticket.getResolution());
        data.put("remark", ticket.getRemark());
        data.put("createTime", ticket.getCreateTime());
        data.put("resolvedTime", ticket.getResolvedTime());

        return Result.success(data);
    }

    private String getStatusLabel(String status) {
        return switch (status) {
            case "PENDING" -> "待处理";
            case "HANDLING" -> "处理中";
            case "RESOLVED" -> "已解决";
            case "CLOSED" -> "已关闭";
            default -> status;
        };
    }
}
