package com.ticket.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ticket.entity.SysUser;
import com.ticket.entity.TicketFaqCandidate;
import com.ticket.service.FaqCandidateService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * FAQ 候选池 Web 页面路由(第五刀 Batch 3)。
 *
 * <p>页面:
 * <ul>
 *   <li>{@code GET /faq-candidate}  - 候选列表页(技术员只看自己的)</li>
 *   <li>{@code GET /faq-candidate/{id}/edit} - 候选编辑页</li>
 * </ul></p>
 *
 * <p>API 路由在 {@link FaqCandidateApiController} 中。</p>
 */
@Controller
@RequestMapping("/faq-candidate")
@RequiredArgsConstructor
@Slf4j
public class FaqCandidateWebController {

    private final FaqCandidateService candidateService;

    /**
     * 候选列表页:展示当前技术员的所有 FAQ 候选(可按 submitStatus 筛选)。
     */
    @GetMapping
    public String listPage(@RequestParam(required = false) String submitStatus,
                           @RequestParam(defaultValue = "1") int pageNum,
                           @RequestParam(defaultValue = "20") int pageSize,
                           HttpSession session, HttpServletRequest request, Model model) {
        SysUser user = (SysUser) session.getAttribute("user");
        if (user == null) return "redirect:/login";

        Page<TicketFaqCandidate> page = candidateService.pageMyCandidates(
                user.getId(), submitStatus, pageNum, pageSize);

        model.addAttribute("candidates", page.getRecords());
        model.addAttribute("total", page.getTotal());
        model.addAttribute("currentStatus", submitStatus);
        model.addAttribute("pageNum", pageNum);
        model.addAttribute("pageSize", pageSize);
        model.addAttribute("totalPages", (page.getTotal() + pageSize - 1) / pageSize);
        model.addAttribute("currentUri", request.getRequestURI());
        return "faq-candidate/list";
    }

    /**
     * 候选编辑页:技术员可修改候选问题/答案/图片/关联功能。
     * 仅 EDITING 态可编辑,SUBMITTED 态进入只读模式。
     */
    @GetMapping("/{id}/edit")
    public String editPage(@PathVariable Long id,
                           HttpSession session, HttpServletRequest request, Model model) {
        SysUser user = (SysUser) session.getAttribute("user");
        if (user == null) return "redirect:/login";

        TicketFaqCandidate candidate = candidateService.getById(id);
        if (candidate == null) {
            return "redirect:/faq-candidate";
        }
        if (!user.getId().equals(candidate.getMarkedById())) {
            return "redirect:/faq-candidate";
        }

        model.addAttribute("candidate", candidate);
        model.addAttribute("readonly", !"EDITING".equals(candidate.getSubmitStatus()));
        model.addAttribute("currentUri", request.getRequestURI());
        return "faq-candidate/edit";
    }

}