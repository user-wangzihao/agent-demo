package com.ticket.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ticket.entity.Ticket;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.time.LocalDate;

@Mapper
public interface TicketMapper extends BaseMapper<Ticket> {

    /**
     * 统计某天 [dayStart, dayEnd) 内创建的工单数（未逻辑删除）.
     * MyBatis-Plus 逻辑删除过滤对 @Select 不自动生效，需手动加 deleted=0.
     */
    @Select("""
            SELECT COUNT(*) FROM ticket
            WHERE deleted = 0
              AND create_time >= #{dayStart}
              AND create_time < #{dayEnd}
            """)
    long countCreatedInRange(@Param("dayStart") LocalDate dayStart,
                             @Param("dayEnd") LocalDate dayEnd);
}