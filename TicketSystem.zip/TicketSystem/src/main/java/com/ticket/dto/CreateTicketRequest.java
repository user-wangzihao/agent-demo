package com.ticket.dto;

import lombok.Data;

/**
 * AgentDemo 提交工单的请求体
 */
@Data
public class CreateTicketRequest {
    /** 来源标识 */
    private String source = "AgentDemo";

    /** 用户ID(AgentDemo中的用户名) */
    private String userId;

    /** 用户昵称 */
    private String userName;

    /** 问题标题 */
    private String title;

    /** 问题描述 */
    private String description;

    /** 完整对话历史(JSON字符串) */
    private String chatHistory;

    /** AgentDemo中的会话ID */
    private String agentSessionId;

    /** 优先级,默认NORMAL */
    private String priority = "NORMAL";

    /** 关联功能ID(可空) */
    private Long relatedFeatureId;

    /** 关联功能名(为空时由Service补默认值"通用FAQ") */
    private String relatedFeatureName;
}