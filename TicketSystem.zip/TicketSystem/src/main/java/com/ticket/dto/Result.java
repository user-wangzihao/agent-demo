package com.ticket.dto;

import lombok.Data;

/**
 * 统一API响应体（供AgentDemo调用）
 */
@Data
public class Result<T> {
    private int code;
    private String message;
    private T data;

    public static <T> Result<T> success(T data) {
        Result<T> r = new Result<>();
        r.code = 200;
        r.message = "success";
        r.data = data;
        return r;
    }

    public static <T> Result<T> fail(String message) {
        Result<T> r = new Result<>();
        r.code = 500;
        r.message = message;
        return r;
    }

    public static <T> Result<T> unauthorized() {
        Result<T> r = new Result<>();
        r.code = 401;
        r.message = "API Key 无效";
        return r;
    }
}
