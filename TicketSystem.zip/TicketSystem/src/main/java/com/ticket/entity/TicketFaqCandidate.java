package com.ticket.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * FAQ 候选编辑表(第五刀)。
 *
 * <p>技术员处理完工单时若勾选"加入FAQ候选池", 自动创建一条候选记录(EDITING 态)。
 * 技术员可在候选池页面编辑问答和图片, 最后提交给 AgentDemo 进入审核流程。</p>
 *
 * @author wzh
 * @since 2026-05-15
 */
@Data
@TableName("ticket_faq_candidate")
public class TicketFaqCandidate {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 关联工单ID */
    private Long ticketId;

    /** 工单编号(冗余字段, 便于列表展示) */
    private String ticketNo;

    /** 问题 */
    private String question;

    /** 问题图片 JSON 数组字符串 */
    private String questionImages;

    /** 答案 */
    private String answer;

    /** 答案图片 JSON 数组字符串 */
    private String answerImages;

    /** 关联功能ID(可空) */
    private Long relatedFeatureId;

    /** 关联功能名(默认"通用FAQ") */
    private String relatedFeatureName;

    /** 标记技术员ID(sys_user.id) */
    private Long markedById;

    /** 标记技术员姓名 */
    private String markedByName;

    /** 提交状态:EDITING / SUBMITTED */
    private String submitStatus;

    /** 正式提交时间(SUBMITTED 时填) */
    private LocalDateTime submittedTime;

    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}