package com.ticket.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 工单实体
 */
@Data
@TableName("ticket")
public class Ticket {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 工单编号，如 TK-20240101-001 */
    private String ticketNo;

    /** 提交来源（如 AgentDemo） */
    private String source;

    /** 用户标识（来自AgentDemo的用户名） */
    private String userId;

    /** 用户昵称 */
    private String userName;

    /** 问题标题（Agent自动总结） */
    private String title;

    /** 问题描述（Agent自动总结的问题摘要） */
    private String description;

    /** 对话历史（JSON格式，完整的对话记录） */
    private String chatHistory;

    /**
     * 工单状态
     * PENDING  - 待处理
     * HANDLING - 处理中
     * RESOLVED - 已解决
     * CLOSED   - 已关闭
     */
    private String status;

    /** 优先级：LOW / NORMAL / HIGH / URGENT */
    private String priority;

    /** 处理人ID */
    private Long handlerId;

    /** 处理人姓名 */
    private String handlerName;

    /** 处理结果 */
    private String resolution;

    /** 处理备注 */
    private String remark;

    /** AgentDemo会话ID，用于关联原始会话 */
    private String agentSessionId;

    /** 关联功能ID(AgentDemo feature_document.id,可为空) */
    private Long relatedFeatureId;

    /** 关联功能名(默认"通用FAQ") */
    private String relatedFeatureName;

    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    /** 处理完成时间 */
    private LocalDateTime resolvedTime;

}
