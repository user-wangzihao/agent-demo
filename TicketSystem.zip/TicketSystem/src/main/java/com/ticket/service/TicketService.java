package com.ticket.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ticket.dto.CreateTicketRequest;
import com.ticket.entity.Ticket;
import com.ticket.mapper.TicketMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
@Service
@RequiredArgsConstructor
public class TicketService {

    private final TicketMapper ticketMapper;

    private final FaqCandidateService faqCandidateService;

    /**
     * 工单编号自增序列 (lazy init + DB 同步).
     *
     * <p><b>Bug 修复</b>: 老版本 {@code AtomicInteger(0)} 进程内固定从 0 起,
     * 重启进程后第一次创建工单总是生成 {@code TK-YYYYMMDD-0001}, 若数据库当天已经存在
     * 同名工单, 会触发 {@code uk_ticket_no} UNIQUE 约束冲突 (DuplicateKeyException),
     * 而 MCP 工具 {@code submitTicket} 抛出的异常被 LLM 包装成 "工单已成功提交,
     * 工单号 TK-xxx" 的 hallucination 回答给用户.</p>
     *
     * <p><b>本次修复</b>: sequence 改为 lazy init + 跨天重置:
     * <ul>
     *   <li>首次调用 / 跨天时, 从数据库查当天 {@code MAX(seq)} 初始化</li>
     *   <li>之后内存自增, 单实例并发安全 (AtomicInteger)</li>
     * </ul>
     * 多实例部署场景仍需引入 Redis/数据库序列, 但本项目单实例足够.</p>
     */
    private static final AtomicInteger sequence = new AtomicInteger(0);
    /** 上次初始化 sequence 时对应的日期, 用于跨天重置. */
    private static volatile LocalDate sequenceDate = null;
    private static final Object sequenceLock = new Object();

    /**
     * 创建工单（AgentDemo调用）
     */
    public Ticket createTicket(CreateTicketRequest req) {
        Ticket ticket = new Ticket();
        ticket.setTicketNo(generateTicketNo());
        ticket.setSource(req.getSource() == null ? "AgentDemo" : req.getSource());
        ticket.setUserId(req.getUserId());
        ticket.setUserName(req.getUserName());
        ticket.setTitle(req.getTitle());
        ticket.setDescription(req.getDescription());
        ticket.setChatHistory(req.getChatHistory());
        ticket.setAgentSessionId(req.getAgentSessionId());
        ticket.setPriority(req.getPriority() == null ? "NORMAL" : req.getPriority());
        // 第五刀新增:feature 关联字段透传(空值兜底为"通用FAQ")
        ticket.setRelatedFeatureId(req.getRelatedFeatureId());
        ticket.setRelatedFeatureName(
                (req.getRelatedFeatureName() == null || req.getRelatedFeatureName().isBlank())
                        ? "通用FAQ" : req.getRelatedFeatureName());
        ticket.setStatus("PENDING");
        ticketMapper.insert(ticket);
        log.info("创建工单成功: {}, feature={}", ticket.getTicketNo(), ticket.getRelatedFeatureName());
        return ticket;
    }

    /**
     * 查询工单状态（AgentDemo调用）
     */
    public Ticket getByTicketNo(String ticketNo) {
        return ticketMapper.selectOne(
                new LambdaQueryWrapper<Ticket>().eq(Ticket::getTicketNo, ticketNo)
        );
    }

    /**
     * 分页查询工单列表（管理后台）
     */
    public Page<Ticket> pageList(int pageNum, int pageSize, String status, String keyword) {
        LambdaQueryWrapper<Ticket> wrapper = new LambdaQueryWrapper<>();
        if (status != null && !status.isBlank()) {
            wrapper.eq(Ticket::getStatus, status);
        }
        if (keyword != null && !keyword.isBlank()) {
            wrapper.and(w -> w.like(Ticket::getTitle, keyword)
                    .or().like(Ticket::getUserName, keyword)
                    .or().like(Ticket::getTicketNo, keyword));
        }
        wrapper.orderByDesc(Ticket::getCreateTime);
        return ticketMapper.selectPage(new Page<>(pageNum, pageSize), wrapper);
    }

    /**
     * 获取工单详情
     */
    public Ticket getById(Long id) {
        return ticketMapper.selectById(id);
    }

    /**
     * 接受工单（开始处理）
     */
    public void acceptTicket(Long id, Long handlerId, String handlerName) {
        Ticket ticket = ticketMapper.selectById(id);
        if (ticket == null) throw new RuntimeException("工单不存在");
        if (!"PENDING".equals(ticket.getStatus())) throw new RuntimeException("工单状态不允许接受");

        ticket.setStatus("HANDLING");
        ticket.setHandlerId(handlerId);
        ticket.setHandlerName(handlerName);
        ticketMapper.updateById(ticket);
    }

    /**
     * 解决工单。
     *
     * @param id              工单ID
     * @param resolution      处理结果
     * @param remark          内部备注
     * @param addToFaqCandidate true 时同步创建一条 FAQ 候选记录(EDITING 态)
     * @param markedById      候选标记技术员ID(addToFaqCandidate=true 时必填)
     * @param markedByName    候选标记技术员姓名
     */
    public void resolveTicket(Long id, String resolution, String remark,
                              boolean addToFaqCandidate,
                              Long markedById, String markedByName) {
        Ticket ticket = ticketMapper.selectById(id);
        if (ticket == null) throw new RuntimeException("工单不存在");

        ticket.setStatus("RESOLVED");
        ticket.setResolution(resolution);
        ticket.setRemark(remark);
        ticket.setResolvedTime(LocalDateTime.now());
        ticketMapper.updateById(ticket);

        // 第五刀:若勾选"加入FAQ候选池", 同步创建候选记录
        if (addToFaqCandidate) {
            faqCandidateService.createFromTicket(ticket, markedById, markedByName);
        }
    }

    /**
     * 关闭工单
     */
    public void closeTicket(Long id) {
        Ticket ticket = ticketMapper.selectById(id);
        if (ticket == null) throw new RuntimeException("工单不存在");
        ticket.setStatus("CLOSED");
        ticketMapper.updateById(ticket);
    }

    /**
     * 统计各状态数量
     */
    public long countByStatus(String status) {
        return ticketMapper.selectCount(
                new LambdaQueryWrapper<Ticket>().eq(Ticket::getStatus, status)
        );
    }

    // ---------- 私有方法 ----------

    private String generateTicketNo() {
        LocalDate today = LocalDate.now();
        String date = today.format(DateTimeFormatter.ofPattern("yyyyMMdd"));

        // lazy init / 跨天重置 sequence
        // 第一次调用 或 日期变了 → 从 DB 查当天 MAX(seq) 重置内存计数器
        if (sequenceDate == null || !sequenceDate.equals(today)) {
            synchronized (sequenceLock) {
                if (sequenceDate == null || !sequenceDate.equals(today)) {
                    int maxSeq = queryMaxSeqOfDate(date);
                    sequence.set(maxSeq);
                    sequenceDate = today;
                    log.info("[TicketSystem] sequence 初始化 date={} startFrom={}", date, maxSeq);
                }
            }
        }

        int seq = sequence.incrementAndGet();
        return String.format("TK-%s-%04d", date, seq);
    }

    /**
     * 查询数据库中给定日期 (YYYYMMDD) 已存在工单号的最大序列号.
     * 若当天还没有工单, 返回 0 (下次 incrementAndGet 得到 1).
     */
    private int queryMaxSeqOfDate(String date) {
        String prefix = "TK-" + date + "-";
        Ticket latest = ticketMapper.selectOne(
                new LambdaQueryWrapper<Ticket>()
                        .likeRight(Ticket::getTicketNo, prefix)
                        .orderByDesc(Ticket::getTicketNo)
                        .last("LIMIT 1")
        );
        if (latest == null) {
            return 0;
        }
        String ticketNo = latest.getTicketNo();
        // ticketNo 形如 "TK-20260515-0042", 取最后 4 位 seq
        try {
            String seqStr = ticketNo.substring(prefix.length());
            return Integer.parseInt(seqStr);
        } catch (Exception e) {
            log.warn("[TicketSystem] 解析 ticketNo 失败 ticketNo={}, 从 0 起算", ticketNo, e);
            return 0;
        }
    }
}