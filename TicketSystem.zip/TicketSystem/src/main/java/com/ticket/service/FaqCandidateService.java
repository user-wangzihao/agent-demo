package com.ticket.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ticket.entity.Ticket;
import com.ticket.entity.TicketFaqCandidate;
import com.ticket.mapper.TicketFaqCandidateMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * FAQ 候选服务(第五刀 Batch 2)。
 *
 * <p>覆盖技术员侧的候选编辑流程:
 * <ol>
 *   <li>工单 resolve 时自动创建候选(EDITING 态)</li>
 *   <li>候选 CRUD(列表/详情/编辑/删除)</li>
 *   <li>提交候选给 AgentDemo(Batch 4 实现 webhook 调用)</li>
 * </ol></p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class FaqCandidateService {

    private final TicketFaqCandidateMapper candidateMapper;

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    @Value("${agent-demo.base-url}")
    private String agentDemoBaseUrl;

    @Value("${agent-demo.internal-api-key}")
    private String agentDemoInternalApiKey;

    /**
     * 工单 resolve 时自动创建候选记录(EDITING 态)。
     * <p>候选初始内容用 ticket 的 title 作为问题, resolution 作为答案,
     * 之后技术员可在候选编辑页修改。</p>
     */
    public TicketFaqCandidate createFromTicket(Ticket ticket, Long markedById, String markedByName) {
        // 防重复:若该工单已有候选, 跳过
        Long existCount = candidateMapper.selectCount(
                new LambdaQueryWrapper<TicketFaqCandidate>()
                        .eq(TicketFaqCandidate::getTicketId, ticket.getId()));
        if (existCount != null && existCount > 0) {
            log.info("[FaqCandidate] 工单已有候选记录, 跳过 ticketId={}", ticket.getId());
            return null;
        }

        TicketFaqCandidate c = new TicketFaqCandidate();
        c.setTicketId(ticket.getId());
        c.setTicketNo(ticket.getTicketNo());
        // 初始问答内容
        c.setQuestion(ticket.getTitle());
        c.setAnswer(ticket.getResolution() == null ? "" : ticket.getResolution());
        // feature 信息继承自工单
        c.setRelatedFeatureId(ticket.getRelatedFeatureId());
        c.setRelatedFeatureName(
                (ticket.getRelatedFeatureName() == null || ticket.getRelatedFeatureName().isBlank())
                        ? "通用FAQ" : ticket.getRelatedFeatureName());
        // 标记人
        c.setMarkedById(markedById);
        c.setMarkedByName(markedByName);
        c.setSubmitStatus("EDITING");

        candidateMapper.insert(c);
        log.info("[FaqCandidate] 创建候选 candidateId={} ticketId={} feature={}",
                c.getId(), ticket.getId(), c.getRelatedFeatureName());
        return c;
    }

    /**
     * 候选列表(分页, 按 marked_by_id 过滤——技术员只看自己的)。
     */
    public Page<TicketFaqCandidate> pageMyCandidates(Long markedById, String submitStatus,
                                                     int pageNum, int pageSize) {
        Page<TicketFaqCandidate> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<TicketFaqCandidate> wrapper = new LambdaQueryWrapper<TicketFaqCandidate>()
                .eq(TicketFaqCandidate::getMarkedById, markedById)
                .orderByDesc(TicketFaqCandidate::getCreateTime);
        if (submitStatus != null && !submitStatus.isBlank()) {
            wrapper.eq(TicketFaqCandidate::getSubmitStatus, submitStatus);
        }
        return candidateMapper.selectPage(page, wrapper);
    }

    /**
     * 获取候选详情。
     */
    public TicketFaqCandidate getById(Long id) {
        return candidateMapper.selectById(id);
    }

    /**
     * 更新候选(只允许 EDITING 态的修改)。
     */
    public void updateCandidate(TicketFaqCandidate update) {
        TicketFaqCandidate existing = candidateMapper.selectById(update.getId());
        if (existing == null) throw new RuntimeException("候选不存在");
        if (!"EDITING".equals(existing.getSubmitStatus())) {
            throw new RuntimeException("候选已提交, 不允许修改;请到 AgentDemo 候选审核页面继续修改");
        }
        // 仅允许内容字段更新, 其他控制字段不受外部修改影响
        TicketFaqCandidate patch = new TicketFaqCandidate();
        patch.setId(update.getId());
        patch.setQuestion(update.getQuestion());
        patch.setQuestionImages(update.getQuestionImages());
        patch.setAnswer(update.getAnswer());
        patch.setAnswerImages(update.getAnswerImages());
        patch.setRelatedFeatureId(update.getRelatedFeatureId());
        patch.setRelatedFeatureName(
                (update.getRelatedFeatureName() == null || update.getRelatedFeatureName().isBlank())
                        ? "通用FAQ" : update.getRelatedFeatureName());
        candidateMapper.updateById(patch);
        log.info("[FaqCandidate] 更新候选 id={}", update.getId());
    }

    /**
     * 删除候选(逻辑删除)。
     * 已提交的候选也允许技术员删除自己的记录(只是从列表里移除, AgentDemo 侧的候选不受影响)。
     */
    public void deleteCandidate(Long id) {
        candidateMapper.deleteById(id);
        log.info("[FaqCandidate] 删除候选 id={}", id);
    }

    /**
     * 标记候选为已提交(Batch 4 webhook 成功后调用)。
     */
    public void markAsSubmitted(Long id) {
        TicketFaqCandidate patch = new TicketFaqCandidate();
        patch.setId(id);
        patch.setSubmitStatus("SUBMITTED");
        patch.setSubmittedTime(LocalDateTime.now());
        candidateMapper.updateById(patch);
    }

    /**
     * 把候选 POST 到 AgentDemo /internal/faq-candidate/submit。
     * <p>成功后才把本地候选状态改为 SUBMITTED。</p>
     */
    public void submitToAgent(Long candidateId, Long markedById) {
        TicketFaqCandidate c = candidateMapper.selectById(candidateId);
        if (c == null) throw new RuntimeException("候选不存在");
        if (!markedById.equals(c.getMarkedById())) throw new RuntimeException("无权操作他人候选");
        if (!"EDITING".equals(c.getSubmitStatus())) throw new RuntimeException("候选状态非 EDITING, 不能再次提交");
        if (c.getQuestion() == null || c.getQuestion().isBlank()) throw new RuntimeException("问题不能为空");
        if (c.getAnswer() == null || c.getAnswer().isBlank()) throw new RuntimeException("答案不能为空");

        // 构造 webhook body, 字段命名必须与 AgentDemo InternalFaqCandidateController 期望一致
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("sourceTicketId", c.getTicketId());
        body.put("sourceTicketNo", c.getTicketNo());
        body.put("submittedById", c.getMarkedById());
        body.put("submittedByName", c.getMarkedByName());
        body.put("question", c.getQuestion());
        body.put("questionImages", c.getQuestionImages());
        body.put("answer", c.getAnswer());
        body.put("answerImages", c.getAnswerImages());
        body.put("relatedFeatureName",
                (c.getRelatedFeatureName() == null || c.getRelatedFeatureName().isBlank())
                        ? "通用FAQ" : c.getRelatedFeatureName());

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("X-Internal-Api-Key", agentDemoInternalApiKey);

        String url = agentDemoBaseUrl + "/internal/faq-candidate/submit";
        try {
            HttpEntity<Map<String, Object>> request = new HttpEntity<>(body, headers);
            ResponseEntity<Map<String, Object>> response = restTemplate.exchange(
                    url, org.springframework.http.HttpMethod.POST, request,
                    new ParameterizedTypeReference<Map<String, Object>>() {});

            if (!response.getStatusCode().is2xxSuccessful()) {
                throw new RuntimeException("AgentDemo 返回非 2xx: " + response.getStatusCode());
            }
            Map<String, Object> respBody = response.getBody();
            if (respBody == null || !"200".equals(String.valueOf(respBody.get("code")))) {
                String msg = respBody == null ? "无响应体" : String.valueOf(respBody.get("message"));
                throw new RuntimeException("AgentDemo 提交失败:" + msg);
            }
            log.info("[FaqCandidate] webhook 提交成功 candidateId={} response={}", candidateId, respBody);
        } catch (Exception e) {
            log.error("[FaqCandidate] webhook 提交失败 candidateId={}", candidateId, e);
            throw new RuntimeException("提交到 AgentDemo 失败:" + e.getMessage(), e);
        }

        // webhook 成功才落本地 SUBMITTED 态
        markAsSubmitted(candidateId);
    }

}