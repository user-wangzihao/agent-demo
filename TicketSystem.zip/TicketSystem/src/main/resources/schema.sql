-- ================================================================
-- 工单系统（TicketSystem）完整建表语句
-- 数据库: ticket_system
-- ================================================================

CREATE DATABASE IF NOT EXISTS ticket_system
    DEFAULT CHARACTER SET utf8mb4
    COLLATE utf8mb4_general_ci;

USE ticket_system;

-- ----------------------------------------------------------------
-- 1. 系统用户表（技术人员）
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sys_user (
    id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    username    VARCHAR(50)  NOT NULL                COMMENT '用户名',
    password    VARCHAR(100) NOT NULL                COMMENT '密码（明文，学习用）',
    nickname    VARCHAR(100) DEFAULT NULL            COMMENT '昵称/显示名',
    role        VARCHAR(20)  NOT NULL DEFAULT 'tech' COMMENT '角色: admin-管理员  tech-技术人员',
    deleted     TINYINT      NOT NULL DEFAULT 0      COMMENT '逻辑删除 0-正常 1-已删除',
    create_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='系统用户表';


-- ----------------------------------------------------------------
-- 2. 工单表
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ticket (
    id               BIGINT        NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
    ticket_no        VARCHAR(30)   NOT NULL                 COMMENT '工单编号，如 TK-20240401-001',

    -- 来源信息
    source           VARCHAR(50)   DEFAULT 'AgentDemo'      COMMENT '来源系统',
    user_id          VARCHAR(100)  DEFAULT NULL             COMMENT '提交用户ID（来自AgentDemo）',
    user_name        VARCHAR(100)  DEFAULT NULL             COMMENT '提交用户昵称',
    agent_session_id VARCHAR(100)  DEFAULT NULL             COMMENT 'AgentDemo会话ID',

    -- 工单内容
    title            VARCHAR(500)  NOT NULL                 COMMENT '问题标题（Agent自动总结）',
    description      TEXT          DEFAULT NULL             COMMENT '问题描述（Agent总结的摘要）',
    chat_history     LONGTEXT      DEFAULT NULL             COMMENT '完整对话历史（JSON数组格式）',

    -- 工单状态
    -- PENDING  待处理
    -- HANDLING 处理中
    -- RESOLVED 已解决
    -- CLOSED   已关闭
    status           VARCHAR(20)   NOT NULL DEFAULT 'PENDING' COMMENT '工单状态',

    -- 优先级: LOW / NORMAL / HIGH / URGENT
    priority         VARCHAR(20)   NOT NULL DEFAULT 'NORMAL'  COMMENT '优先级',

    -- 处理信息
    handler_id       BIGINT        DEFAULT NULL             COMMENT '处理人ID（sys_user.id）',
    handler_name     VARCHAR(100)  DEFAULT NULL             COMMENT '处理人姓名',
    resolution       TEXT          DEFAULT NULL             COMMENT '处理结果（反馈给用户）',
    remark           TEXT          DEFAULT NULL             COMMENT '内部备注（不展示给用户）',

    -- 时间字段
    resolved_time    DATETIME      DEFAULT NULL             COMMENT '处理完成时间',
    deleted          TINYINT       NOT NULL DEFAULT 0       COMMENT '逻辑删除 0-正常 1-已删除',
    create_time      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uk_ticket_no (ticket_no),
    KEY idx_status (status),
    KEY idx_user_id (user_id),
    KEY idx_agent_session_id (agent_session_id),
    KEY idx_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='工单表';


-- ----------------------------------------------------------------
-- 初始化用户数据
-- ----------------------------------------------------------------
INSERT IGNORE INTO sys_user (username, password, nickname, role) VALUES
('admin', 'admin123', '管理员',   'admin'),
('tech',  'tech123',  '技术人员', 'tech');


-- ================================================================
-- 字段说明补充
-- ================================================================
--
-- ticket.chat_history 存储格式示例（JSON数组）：
-- [
--   {"role": "user",      "content": "这个功能点击后没反应怎么办"},
--   {"role": "assistant", "content": "您好，请先检查..."},
--   {"role": "user",      "content": "还是不行，帮我转给技术人员"},
--   {"role": "assistant", "content": "好的，我已为您创建工单..."}
-- ]
--
-- ticket.status 流转规则：
--   PENDING → HANDLING（技术人员接受）
--   HANDLING → RESOLVED（技术人员填写处理结果）
--   任意状态 → CLOSED（强制关闭）
--
-- ================================================================