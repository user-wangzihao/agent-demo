package com.ticket.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ticket.dto.CreateTicketRequest;
import com.ticket.entity.Ticket;
import com.ticket.mapper.TicketMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
@Service
@RequiredArgsConstructor
public class TicketService {

    private final TicketMapper ticketMapper;

    private final FaqCandidateService faqCandidateService;

    // 工单编号自增序列（生产环境应用数据库序列或Redis）
    private static final AtomicInteger sequence = new AtomicInteger(0);

    /**
     * 创建工单（AgentDemo调用）
     */
    public Ticket createTicket(CreateTicketRequest req) {
        Ticket ticket = new Ticket();
        ticket.setTicketNo(generateTicketNo());
        ticket.setSource(req.getSource() == null ? "AgentDemo" : req.getSource());
        ticket.setUserId(req.getUserId());
        ticket.setUserName(req.getUserName());
        ticket.setTitle(req.getTitle());
        ticket.setDescription(req.getDescription());
        ticket.setChatHistory(req.getChatHistory());
        ticket.setAgentSessionId(req.getAgentSessionId());
        ticket.setPriority(req.getPriority() == null ? "NORMAL" : req.getPriority());
        // 第五刀新增:feature 关联字段透传(空值兜底为"通用FAQ")
        ticket.setRelatedFeatureId(req.getRelatedFeatureId());
        ticket.setRelatedFeatureName(
                (req.getRelatedFeatureName() == null || req.getRelatedFeatureName().isBlank())
                        ? "通用FAQ" : req.getRelatedFeatureName());
        ticket.setStatus("PENDING");
        ticketMapper.insert(ticket);
        log.info("创建工单成功: {}, feature={}", ticket.getTicketNo(), ticket.getRelatedFeatureName());
        return ticket;
    }

    /**
     * 查询工单状态（AgentDemo调用）
     */
    public Ticket getByTicketNo(String ticketNo) {
        return ticketMapper.selectOne(
                new LambdaQueryWrapper<Ticket>().eq(Ticket::getTicketNo, ticketNo)
        );
    }

    /**
     * 分页查询工单列表（管理后台）
     */
    public Page<Ticket> pageList(int pageNum, int pageSize, String status, String keyword) {
        LambdaQueryWrapper<Ticket> wrapper = new LambdaQueryWrapper<>();
        if (status != null && !status.isBlank()) {
            wrapper.eq(Ticket::getStatus, status);
        }
        if (keyword != null && !keyword.isBlank()) {
            wrapper.and(w -> w.like(Ticket::getTitle, keyword)
                    .or().like(Ticket::getUserName, keyword)
                    .or().like(Ticket::getTicketNo, keyword));
        }
        wrapper.orderByDesc(Ticket::getCreateTime);
        return ticketMapper.selectPage(new Page<>(pageNum, pageSize), wrapper);
    }

    /**
     * 获取工单详情
     */
    public Ticket getById(Long id) {
        return ticketMapper.selectById(id);
    }

    /**
     * 接受工单（开始处理）
     */
    public void acceptTicket(Long id, Long handlerId, String handlerName) {
        Ticket ticket = ticketMapper.selectById(id);
        if (ticket == null) throw new RuntimeException("工单不存在");
        if (!"PENDING".equals(ticket.getStatus())) throw new RuntimeException("工单状态不允许接受");

        ticket.setStatus("HANDLING");
        ticket.setHandlerId(handlerId);
        ticket.setHandlerName(handlerName);
        ticketMapper.updateById(ticket);
    }

    /**
     * 解决工单。
     *
     * @param id              工单ID
     * @param resolution      处理结果
     * @param remark          内部备注
     * @param addToFaqCandidate true 时同步创建一条 FAQ 候选记录(EDITING 态)
     * @param markedById      候选标记技术员ID(addToFaqCandidate=true 时必填)
     * @param markedByName    候选标记技术员姓名
     */
    public void resolveTicket(Long id, String resolution, String remark,
                              boolean addToFaqCandidate,
                              Long markedById, String markedByName) {
        Ticket ticket = ticketMapper.selectById(id);
        if (ticket == null) throw new RuntimeException("工单不存在");

        ticket.setStatus("RESOLVED");
        ticket.setResolution(resolution);
        ticket.setRemark(remark);
        ticket.setResolvedTime(LocalDateTime.now());
        ticketMapper.updateById(ticket);

        // 第五刀:若勾选"加入FAQ候选池", 同步创建候选记录
        if (addToFaqCandidate) {
            faqCandidateService.createFromTicket(ticket, markedById, markedByName);
        }
    }

    /**
     * 关闭工单
     */
    public void closeTicket(Long id) {
        Ticket ticket = ticketMapper.selectById(id);
        if (ticket == null) throw new RuntimeException("工单不存在");
        ticket.setStatus("CLOSED");
        ticketMapper.updateById(ticket);
    }

    /**
     * 统计各状态数量
     */
    public long countByStatus(String status) {
        return ticketMapper.selectCount(
                new LambdaQueryWrapper<Ticket>().eq(Ticket::getStatus, status)
        );
    }

    // ---------- 私有方法 ----------

    private String generateTicketNo() {
        String date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        int seq = sequence.incrementAndGet();
        return String.format("TK-%s-%04d", date, seq);
    }
}
